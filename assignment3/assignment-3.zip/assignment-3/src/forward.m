function [z2,a2,z3,yHat] = forward( X, w1, w2 )
%forward propagation
z2 = X*w1;
a2 = activationFunction(z2);
z3 = a2*w2;
yHat = activationFunction(z3);
end

