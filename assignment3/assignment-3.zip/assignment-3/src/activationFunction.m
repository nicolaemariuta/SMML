function  O  = activationFunction( I )
O = 1./(1+abs(I));
end

