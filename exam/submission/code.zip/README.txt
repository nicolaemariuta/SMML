In order to run the code in my submission, you need to have installed at least Matlab 2014 and the LIBSVM from the website
http://www.csie.ntu.edu.tw/~cjlin/libsvm/ for running the parts of the code where I used SVM.
The file main.m must be run to reproduce all the results presented in my report. I have also displayed meaningful
messages in the console, and labels on plots but it is still better to run each section of the code sepparately in order to 
view the results for each task sepparately.   

